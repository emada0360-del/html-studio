import 'dart:convert';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'github.dart';
import 'gen.dart';
import 'store.dart';

export 'store.dart' show Project;

const _textExt = {'html', 'htm', 'css', 'js', 'json', 'txt', 'svg', 'xml', 'md'};
String _ext(String n) => n.contains('.') ? n.split('.').last.toLowerCase() : '';

class ProjectScreen extends StatefulWidget {
  final Project p;
  const ProjectScreen(this.p, {super.key});
  @override
  State<ProjectScreen> createState() => _ProjectScreenState();
}

class _ProjectScreenState extends State<ProjectScreen> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final p = widget.p;
    return Scaffold(
      appBar: AppBar(title: Text(p.name), actions: [
        IconButton(
          icon: const Icon(Icons.play_circle_outline),
          tooltip: 'معاينة',
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PreviewScreen(p))),
        ),
      ]),
      body: IndexedStack(index: tab, children: [FilesTab(p), SettingsTab(p), BuildTab(p)]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.folder_outlined), label: 'الملفات'),
          NavigationDestination(icon: Icon(Icons.tune), label: 'إعدادات التطبيق'),
          NavigationDestination(icon: Icon(Icons.rocket_launch_outlined), label: 'بناء ونشر'),
        ],
      ),
    );
  }
}

// ---------------- Files ----------------
class FilesTab extends StatefulWidget {
  final Project p;
  const FilesTab(this.p, {super.key});
  @override
  State<FilesTab> createState() => _FilesTabState();
}

class _FilesTabState extends State<FilesTab> {
  Project get p => widget.p;

  void msg(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> newFile() async {
    final c = TextEditingController();
    final n = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('ملف جديد'),
        content: TextField(controller: c, autofocus: true, textDirection: TextDirection.ltr, decoration: const InputDecoration(hintText: 'page2.html أو css/main.css')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('إنشاء')),
        ],
      ),
    );
    if (n == null || n.isEmpty || n.contains('..')) return;
    final f = File('${p.www.path}/$n');
    await f.create(recursive: true);
    setState(() {});
  }

  Future<void> importFiles() async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (r == null) return;
    for (final f in r.files) {
      if (f.path != null) await File(f.path!).copy('${p.www.path}/${f.name}');
    }
    setState(() {});
  }

  void addMenu() => showModalBottomSheet(
        context: context,
        builder: (_) => SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(leading: const Icon(Icons.note_add), title: const Text('ملف جديد (HTML / CSS / JS)'), onTap: () { Navigator.pop(context); newFile(); }),
            ListTile(leading: const Icon(Icons.upload_file), title: const Text('استيراد ملفات (صور، خطوط، ...)'), onTap: () { Navigator.pop(context); importFiles(); }),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final fs = p.files();
    return Scaffold(
      body: fs.isEmpty
          ? const Center(child: Text('ما في ملفات'))
          : ListView(children: [
              for (final f in fs)
                ListTile(
                  leading: Icon(_textExt.contains(_ext(f.path)) ? Icons.code : Icons.image_outlined),
                  title: Text(p.rel(f), textDirection: TextDirection.ltr, textAlign: TextAlign.right),
                  subtitle: Text('${(f.lengthSync() / 1024).toStringAsFixed(1)} KB'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      if (p.rel(f) == 'index.html') return msg('ما تقدر تحذف index.html');
                      await f.delete();
                      setState(() {});
                    },
                  ),
                  onTap: () async {
                    if (!_textExt.contains(_ext(f.path))) return msg('هذا ملف غير نصي، ما ينفتح بالمحرر');
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => EditorScreen(f, p.rel(f))));
                    setState(() {});
                  },
                ),
            ]),
      floatingActionButton: FloatingActionButton.extended(onPressed: addMenu, icon: const Icon(Icons.add), label: const Text('إضافة')),
    );
  }
}

class EditorScreen extends StatefulWidget {
  final File f;
  final String title;
  const EditorScreen(this.f, this.title, {super.key});
  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late final TextEditingController c = TextEditingController(text: widget.f.readAsStringSync());
  final fn = FocusNode();

  void ins(String s) {
    final v = c.value;
    final sel = v.selection;
    final st = sel.isValid ? sel.start : v.text.length;
    final en = sel.isValid ? sel.end : st;
    c.value = TextEditingValue(text: v.text.replaceRange(st, en, s), selection: TextSelection.collapsed(offset: st + s.length));
    fn.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    const keys = ['<', '>', '/', '"', '=', '{', '}', '(', ')', ';', ':', '  '];
    return PopScope(
      canPop: true,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) widget.f.writeAsStringSync(c.text);
      },
      child: Scaffold(
        appBar: AppBar(title: Text(widget.title, textDirection: TextDirection.ltr), actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: () {
              widget.f.writeAsStringSync(c.text);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم الحفظ'), duration: Duration(seconds: 1)));
            },
          ),
        ]),
        body: Column(children: [
          Expanded(
            child: TextField(
              controller: c,
              focusNode: fn,
              maxLines: null,
              expands: true,
              textAlignVertical: TextAlignVertical.top,
              keyboardType: TextInputType.multiline,
              textDirection: TextDirection.ltr,
              autocorrect: false,
              enableSuggestions: false,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 14),
              decoration: const InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.all(12)),
            ),
          ),
          SizedBox(
            height: 44,
            child: ListView(scrollDirection: Axis.horizontal, children: [
              for (final k in keys)
                InkWell(
                  canRequestFocus: false,
                  onTap: () => ins(k),
                  child: Container(
                    width: 44,
                    alignment: Alignment.center,
                    child: Text(k.trim().isEmpty ? '⇥' : k, style: const TextStyle(fontSize: 20, fontFamily: 'monospace')),
                  ),
                ),
            ]),
          ),
        ]),
      ),
    );
  }
}

class PreviewScreen extends StatefulWidget {
  final Project p;
  const PreviewScreen(this.p, {super.key});
  @override
  State<PreviewScreen> createState() => _PreviewScreenState();
}

class _PreviewScreenState extends State<PreviewScreen> {
  WebViewController? c;
  @override
  void initState() {
    super.initState();
    final f = File('${widget.p.www.path}/index.html');
    if (f.existsSync()) {
      c = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..loadFile(f.path);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('معاينة')),
        body: c == null ? const Center(child: Text('ما في index.html')) : WebViewWidget(controller: c!),
      );
}

// ---------------- App settings ----------------
class SettingsTab extends StatefulWidget {
  final Project p;
  const SettingsTab(this.p, {super.key});
  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  Project get p => widget.p;
  late final name = TextEditingController(text: p.name);
  late final pkg = TextEditingController(text: p.package);
  late final vn = TextEditingController(text: p.vName);
  late final vc = TextEditingController(text: '${p.vCode}');

  void msg(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> save() async {
    if (!RegExp(r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$').hasMatch(pkg.text.trim())) {
      return msg('Package ID غير صحيح. مثال: com.mycompany.myapp');
    }
    final code = int.tryParse(vc.text.trim());
    if (code == null || code < 1) return msg('Version Code لازم يكون رقم 1 أو أكثر');
    p.name = name.text.trim().isEmpty ? p.name : name.text.trim();
    p.package = pkg.text.trim();
    p.vName = vn.text.trim();
    p.vCode = code;
    await p.save();
    msg('تم الحفظ');
  }

  Future<void> pickIcon() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.image);
    if (r == null || r.files.single.path == null) return;
    await File(r.files.single.path!).copy(p.icon.path);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم التطبيق', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: pkg, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'Package ID', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: TextField(controller: vn, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'Version Name', border: OutlineInputBorder()))),
          const SizedBox(width: 8),
          Expanded(child: TextField(controller: vc, keyboardType: TextInputType.number, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'Version Code', border: OutlineInputBorder()))),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          if (p.icon.existsSync()) ...[
            ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(p.icon, width: 56, height: 56, fit: BoxFit.cover, key: UniqueKey())),
            const SizedBox(width: 12),
          ],
          Expanded(child: OutlinedButton.icon(onPressed: pickIcon, icon: const Icon(Icons.image), label: const Text('أيقونة التطبيق (PNG مربعة 1024×1024)'))),
        ]),
        const SizedBox(height: 16),
        FilledButton(onPressed: save, child: const Text('حفظ')),
      ]);
}

// ---------------- Build ----------------
class BuildTab extends StatefulWidget {
  final Project p;
  const BuildTab(this.p, {super.key});
  @override
  State<BuildTab> createState() => _BuildTabState();
}

class _BuildTabState extends State<BuildTab> {
  Project get p => widget.p;
  final logs = <String>[];
  bool busy = false;

  void log(String s) {
    if (mounted) setState(() => logs.add(s));
  }

  File get aab => File('${p.out.path}/app-release.aab');
  File get apk => File('${p.out.path}/app-release.apk');
  File get keyB64 => File('${p.signing.path}/upload-keystore.b64');
  File get keyPass => File('${p.signing.path}/pass.txt');

  Future<void> startBuild() async {
    final sp = await SharedPreferences.getInstance();
    final token = sp.getString('gh_token') ?? '';
    if (token.isEmpty) return log('❌ أدخل توكن GitHub أولاً (أيقونة الترس بالصفحة الرئيسية)');
    if (!File('${p.www.path}/index.html').existsSync()) return log('❌ لازم يكون عندك ملف index.html');
    if (!RegExp(r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$').hasMatch(p.package)) return log('❌ Package ID غير صحيح، عدّله من إعدادات التطبيق');

    setState(() {
      busy = true;
      logs.clear();
    });
    try {
      final gh = GH(token);
      log('🔑 فحص الحساب...');
      await gh.init();
      log('👤 ${gh.owner}');
      p.repo ??= 'h2f-${Store.slug(p.name).replaceAll('_', '-')}-${p.id.substring(p.id.length - 5)}';
      await p.save();
      log('📦 تجهيز المستودع الخاص...');
      final branch = await gh.ensureRepo(p.repo!);
      log('⬆️ رفع الملفات...');
      final hadKey = keyB64.existsSync() && keyPass.existsSync();
      final sha = await gh.push(p.repo!, branch, await Gen.files(p), 'Build ${p.vName}+${p.vCode}');
      log('⚙️ بدأ البناء على GitHub (يأخذ 5-10 دقائق)...');

      Map<String, dynamic>? run;
      for (var i = 0; i < 30 && run == null; i++) {
        run = await gh.runFor(p.repo!, sha);
        if (run == null) await Future.delayed(const Duration(seconds: 4));
      }
      if (run == null) throw 'ما ظهر تشغيل للبناء. تأكد أن التوكن فيه صلاحية workflow';
      final runId = run['id'] as int;
      var last = '';
      for (var i = 0; i < 240; i++) {
        run = await gh.getRun(p.repo!, runId);
        final st = '${run['status']}';
        if (st != last) {
          last = st;
          log('⏳ الحالة: $st');
        }
        if (st == 'completed') break;
        await Future.delayed(const Duration(seconds: 10));
      }
      if (run!['conclusion'] != 'success') {
        throw 'فشل البناء (${run['conclusion']}).\nسجل البناء: ${run['html_url']}';
      }

      log('⬇️ تنزيل الملفات...');
      await p.out.create(recursive: true);
      for (final a in await gh.artifacts(p.repo!, runId)) {
        final n = a['name'];
        if (n == 'release-files') {
          final z = ZipDecoder().decodeBytes(await gh.artifactZip(p.repo!, a['id']));
          for (final f in z.files) {
            if (f.isFile) await File('${p.out.path}/${f.name.split('/').last}').writeAsBytes(f.content as List<int>);
          }
        } else if (n == 'KEEP-SECRET-keystore' && !hadKey) {
          final z = ZipDecoder().decodeBytes(await gh.artifactZip(p.repo!, a['id']));
          await p.signing.create(recursive: true);
          for (final f in z.files) {
            if (!f.isFile) continue;
            final b = f.content as List<int>;
            final fname = f.name.split('/').last;
            if (fname.endsWith('.jks')) {
              await keyB64.writeAsString(base64Encode(b));
            } else if (fname.contains('password')) {
              final m = RegExp(r'KEYSTORE_PASSWORD=(\S+)').firstMatch(utf8.decode(b));
              if (m != null) await keyPass.writeAsString(m.group(1)!);
            }
          }
          log('🔐 تم حفظ مفتاح التوقيع (احتفظ بنسخة منه)');
        }
      }
      p.vCode += 1;
      await p.save();
      log('✅ تم! الملفات جاهزة بالأسفل. (رقم الإصدار صار ${p.vCode} للبناء القادم)');
    } catch (e) {
      log('❌ $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> share(List<File> f) => Share.shareXFiles(f.map((e) => XFile(e.path)).toList());

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          FilledButton.icon(
            onPressed: busy ? null : startBuild,
            icon: busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.rocket_launch),
            label: Text(busy ? 'جاري البناء...' : 'ابنِ التطبيق (APK + AAB)'),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: Card(
              child: ListView(padding: const EdgeInsets.all(12), children: [
                if (logs.isEmpty) const Text('اضغط الزر: يرفع مشروعك لـ GitHub، يبنيه، وينزّل لك ملفات APK و AAB موقّعة.', style: TextStyle(height: 1.6)),
                for (final l in logs) Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: SelectableText(l)),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          if (aab.existsSync()) OutlinedButton.icon(onPressed: () => share([aab]), icon: const Icon(Icons.shop), label: const Text('حفظ/مشاركة AAB (لـ Google Play)')),
          if (apk.existsSync()) OutlinedButton.icon(onPressed: () => share([apk]), icon: const Icon(Icons.android), label: const Text('حفظ/مشاركة APK (للتجربة والتثبيت)')),
          if (keyB64.existsSync() && keyPass.existsSync())
            OutlinedButton.icon(onPressed: () => share([keyB64, keyPass]), icon: const Icon(Icons.key), label: const Text('تصدير نسخة احتياطية من مفتاح التوقيع')),
        ]),
      );
}
