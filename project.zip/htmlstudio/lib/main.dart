import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'project_screen.dart';
import 'store.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Store.init();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'HTML Studio',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF1E6FFF)),
        builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<Project> ps = Store.all();
  void refresh() => setState(() => ps = Store.all());

  Future<void> newProject() async {
    final c = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('مشروع جديد'),
        content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(labelText: 'اسم التطبيق')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('إنشاء')),
        ],
      ),
    );
    if (name == null || name.isEmpty) return;
    final p = await Store.create(name);
    refresh();
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => ProjectScreen(p)));
    refresh();
  }

  Future<void> remove(Project p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('حذف ${p.name}؟'),
        content: const Text('راح تنحذف كل ملفات المشروع من الجوال.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
        ],
      ),
    );
    if (ok == true) {
      await Store.delete(p);
      refresh();
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('HTML Studio'), actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: 'إعدادات GitHub',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GitHubSettings())),
          ),
        ]),
        body: ps.isEmpty
            ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('ما عندك مشاريع بعد.\nاضغط "مشروع جديد" وابدأ.', textAlign: TextAlign.center)))
            : ListView(children: [
                for (final p in ps)
                  ListTile(
                    leading: p.icon.existsSync()
                        ? ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.file(p.icon, width: 44, height: 44, fit: BoxFit.cover))
                        : const Icon(Icons.android, size: 40),
                    title: Text(p.name),
                    subtitle: Text('${p.package}  •  v${p.vName} (${p.vCode})', textDirection: TextDirection.ltr),
                    trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => remove(p)),
                    onTap: () async {
                      await Navigator.push(context, MaterialPageRoute(builder: (_) => ProjectScreen(p)));
                      refresh();
                    },
                  ),
              ]),
        floatingActionButton: FloatingActionButton.extended(onPressed: newProject, icon: const Icon(Icons.add), label: const Text('مشروع جديد')),
      );
}

class GitHubSettings extends StatefulWidget {
  const GitHubSettings({super.key});
  @override
  State<GitHubSettings> createState() => _GitHubSettingsState();
}

class _GitHubSettingsState extends State<GitHubSettings> {
  final c = TextEditingController();
  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((s) => setState(() => c.text = s.getString('gh_token') ?? ''));
  }

  Future<void> save() async {
    final s = await SharedPreferences.getInstance();
    await s.setString('gh_token', c.text.trim());
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم الحفظ')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('إعدادات GitHub')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Text(
            'البناء يصير مجاناً على سيرفرات GitHub. تحتاج مرة وحدة:\n\n'
            '1) سوي حساب على github.com\n'
            '2) من المتصفح: Settings ← Developer settings ← Personal access tokens ← Tokens (classic) ← Generate new token\n'
            '3) فعّل الصلاحيتين: repo و workflow\n'
            '4) انسخ التوكن والصقه هنا.\n\n'
            'التطبيق ينشئ مستودع خاص (Private) لكل مشروع تلقائياً.',
            style: TextStyle(height: 1.6),
          ),
          const SizedBox(height: 16),
          TextField(controller: c, obscureText: true, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'GitHub Token', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          FilledButton(onPressed: save, child: const Text('حفظ')),
        ]),
      );
}
