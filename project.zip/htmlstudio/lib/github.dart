import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;

class GH {
  final String token;
  String owner = '';
  GH(this.token);

  Map<String, String> get _h => {
        'Authorization': 'Bearer $token',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
      };

  Future<dynamic> _j(String m, String path, [Object? body]) async {
    final req = http.Request(m, Uri.parse('https://api.github.com$path'))..headers.addAll(_h);
    if (body != null) {
      req.headers['Content-Type'] = 'application/json';
      req.body = jsonEncode(body);
    }
    final res = await http.Response.fromStream(await req.send());
    if (res.statusCode >= 300) throw 'GitHub ${res.statusCode}: ${res.body}';
    return res.body.isEmpty ? null : jsonDecode(res.body);
  }

  Future<void> init() async {
    final u = await _j('GET', '/user');
    owner = u['login'];
  }

  Future<String> ensureRepo(String name) async {
    try {
      final r = await _j('GET', '/repos/$owner/$name');
      return r['default_branch'];
    } catch (e) {
      if (!'$e'.contains('404')) rethrow;
    }
    final r = await _j('POST', '/user/repos', {'name': name, 'private': true, 'auto_init': true});
    return r['default_branch'];
  }

  /// Replaces the whole repo tree with [files] in a single commit. Returns commit sha.
  Future<String> push(String repo, String branch, Map<String, List<int>> files, String msg) async {
    String? head;
    for (var i = 0; i < 10; i++) {
      try {
        final r = await _j('GET', '/repos/$owner/$repo/git/ref/heads/$branch');
        head = r['object']['sha'];
        break;
      } catch (_) {
        await Future.delayed(const Duration(seconds: 2));
      }
    }
    if (head == null) throw 'تعذر قراءة المستودع';
    final tree = <Map<String, String>>[];
    for (final e in files.entries) {
      final b = await _j('POST', '/repos/$owner/$repo/git/blobs', {'content': base64Encode(e.value), 'encoding': 'base64'});
      tree.add({'path': e.key, 'mode': '100644', 'type': 'blob', 'sha': b['sha']});
    }
    final t = await _j('POST', '/repos/$owner/$repo/git/trees', {'tree': tree});
    final c = await _j('POST', '/repos/$owner/$repo/git/commits', {'message': msg, 'tree': t['sha'], 'parents': [head]});
    await _j('PATCH', '/repos/$owner/$repo/git/refs/heads/$branch', {'sha': c['sha'], 'force': true});
    return c['sha'];
  }

  Future<Map<String, dynamic>?> runFor(String repo, String sha) async {
    final r = await _j('GET', '/repos/$owner/$repo/actions/runs?head_sha=$sha');
    final l = r['workflow_runs'] as List;
    return l.isEmpty ? null : Map<String, dynamic>.from(l.first);
  }

  Future<Map<String, dynamic>> getRun(String repo, int id) async =>
      Map<String, dynamic>.from(await _j('GET', '/repos/$owner/$repo/actions/runs/$id'));

  Future<List<Map<String, dynamic>>> artifacts(String repo, int runId) async {
    final r = await _j('GET', '/repos/$owner/$repo/actions/runs/$runId/artifacts');
    return (r['artifacts'] as List).map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<Uint8List> artifactZip(String repo, int id) async {
    final c = http.Client();
    final req = http.Request('GET', Uri.parse('https://api.github.com/repos/$owner/$repo/actions/artifacts/$id/zip'))
      ..followRedirects = false
      ..headers.addAll(_h);
    final res = await c.send(req);
    final loc = res.headers['location'];
    if (loc == null) throw 'تعذر تنزيل الملف (${res.statusCode})';
    final r2 = await http.get(Uri.parse(loc));
    return r2.bodyBytes;
  }
}
