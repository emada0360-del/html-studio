import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class Project {
  String id, name, package, vName;
  int vCode;
  String? repo;
  Project({required this.id, required this.name, required this.package, this.vName = '1.0.0', this.vCode = 1, this.repo});

  Directory get dir => Directory('${Store.root.path}/$id');
  Directory get www => Directory('${dir.path}/www');
  Directory get signing => Directory('${dir.path}/signing');
  Directory get out => Directory('${dir.path}/out');
  File get icon => File('${dir.path}/icon.png');

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'package': package, 'vName': vName, 'vCode': vCode, 'repo': repo};
  factory Project.fromJson(Map<String, dynamic> j) => Project(
        id: j['id'], name: j['name'], package: j['package'],
        vName: j['vName'] ?? '1.0.0', vCode: j['vCode'] ?? 1, repo: j['repo']);

  Future<void> save() async {
    await dir.create(recursive: true);
    await File('${dir.path}/project.json').writeAsString(jsonEncode(toJson()));
  }

  List<File> files() {
    if (!www.existsSync()) return [];
    final l = www.listSync(recursive: true).whereType<File>().toList();
    l.sort((a, b) => a.path.compareTo(b.path));
    return l;
  }

  String rel(File f) => f.path.substring(www.path.length + 1);
}

class Store {
  static late Directory root;

  static Future<void> init() async {
    root = Directory('${(await getApplicationDocumentsDirectory()).path}/projects');
    await root.create(recursive: true);
  }

  static String slug(String s) {
    var r = s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_').replaceAll(RegExp(r'^_+|_+$'), '');
    if (r.isEmpty) return 'app';
    if (RegExp(r'^[0-9]').hasMatch(r)) return 'app_$r';
    return r;
  }

  static List<Project> all() {
    final l = <Project>[];
    for (final d in root.listSync().whereType<Directory>()) {
      final f = File('${d.path}/project.json');
      if (f.existsSync()) {
        try {
          l.add(Project.fromJson(jsonDecode(f.readAsStringSync())));
        } catch (_) {}
      }
    }
    l.sort((a, b) => b.id.compareTo(a.id));
    return l;
  }

  static Future<Project> create(String name) async {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final p = Project(id: id, name: name, package: 'com.example.${slug(name).replaceAll('_', '')}${id.substring(id.length - 4)}');
    await p.www.create(recursive: true);
    await File('${p.www.path}/index.html').writeAsString(_html);
    await File('${p.www.path}/style.css').writeAsString(_css);
    await File('${p.www.path}/script.js').writeAsString(_js);
    await p.save();
    return p;
  }

  static Future<void> delete(Project p) async {
    if (p.dir.existsSync()) await p.dir.delete(recursive: true);
  }
}

const _html = r'''<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>تطبيقي</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1>مرحباً بك 👋</h1>
  <p>هذا تطبيقي الأول.</p>
  <button id="btn">اضغط هنا</button>
  <script src="script.js"></script>
</body>
</html>
''';

const _css = r'''body {
  font-family: sans-serif;
  text-align: center;
  padding: 40px 16px;
  background: #f4f6fb;
}
button {
  font-size: 18px;
  padding: 12px 28px;
  border: 0;
  border-radius: 12px;
  background: #1e6fff;
  color: #fff;
}
''';

const _js = r'''document.getElementById('btn').addEventListener('click', function () {
  alert('اشتغل التطبيق!');
});
''';
