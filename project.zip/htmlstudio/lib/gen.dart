import 'dart:convert';
import 'dart:io';
import 'store.dart';

class Gen {
  static Future<Map<String, List<int>>> files(Project p) async {
    final out = <String, List<int>>{};
    final dirs = <String>{'assets/www/'};
    for (final f in p.files()) {
      final r = p.rel(f).replaceAll('\\', '/');
      out['assets/www/$r'] = await f.readAsBytes();
      final i = r.lastIndexOf('/');
      if (i > 0) dirs.add('assets/www/${r.substring(0, i)}/');
    }
    final parts = p.package.split('.');
    final project = Store.slug(parts.last);
    final org = parts.sublist(0, parts.length - 1).join('.');
    final name = p.name.replaceAll(RegExp(r'''['"$\\<>&]'''), '');
    String fill(String t) => t
        .replaceAll('__NAME__', name)
        .replaceAll('__PROJECT__', project)
        .replaceAll('__ORG__', org)
        .replaceAll('__VNAME__', p.vName)
        .replaceAll('__VCODE__', '${p.vCode}');

    var pub = fill(_pubTpl).replaceAll('__ASSETS__', (dirs.toList()..sort()).map((d) => '    - $d').join('\n'));
    if (p.icon.existsSync()) {
      pub += _iconCfg;
      out['assets/icon.png'] = await p.icon.readAsBytes();
    }
    out['pubspec.yaml'] = utf8.encode(pub);
    out['lib/main.dart'] = utf8.encode(fill(_mainTpl));
    out['.github/workflows/build.yml'] = utf8.encode(fill(_ciTpl));
    out['tools/patch_signing.py'] = utf8.encode(_patchPy);
    final k = File('${p.signing.path}/upload-keystore.b64');
    final pw = File('${p.signing.path}/pass.txt');
    if (k.existsSync() && pw.existsSync()) {
      out['signing/upload-keystore.b64'] = await k.readAsBytes();
      out['signing/pass.txt'] = await pw.readAsBytes();
    }
    return out;
  }
}

const _mainTpl = r'''
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: '__NAME__',
        debugShowCheckedModeBanner: false,
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  late final WebViewController c;
  @override
  void initState() {
    super.initState();
    c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadFlutterAsset('assets/www/index.html');
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) async {
          if (await c.canGoBack()) {
            c.goBack();
          } else {
            SystemNavigator.pop();
          }
        },
        child: Scaffold(body: SafeArea(child: WebViewWidget(controller: c))),
      );
}
''';

const _pubTpl = r'''
name: __PROJECT__
description: __NAME__
publish_to: none
version: __VNAME__+__VCODE__
environment:
  sdk: '>=3.3.0 <4.0.0'
dependencies:
  flutter:
    sdk: flutter
  webview_flutter: ^4.10.0
flutter:
  uses-material-design: true
  assets:
__ASSETS__
''';

const _iconCfg = r'''

dev_dependencies:
  flutter_launcher_icons: ^0.14.1

flutter_launcher_icons:
  android: true
  ios: false
  image_path: assets/icon.png
''';

const _ciTpl = r'''
name: Build Release
on:
  push:
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: subosito/flutter-action@v2
        with:
          channel: stable
      - run: flutter create --org __ORG__ --project-name __PROJECT__ --platforms=android .
      - run: sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <application#' android/app/src/main/AndroidManifest.xml
      - run: sed -i 's#android:label="[^"]*"#android:label="__NAME__"#' android/app/src/main/AndroidManifest.xml
      - run: flutter pub get
      - name: Generate launcher icons
        run: |
          if [ -f assets/icon.png ]; then dart run flutter_launcher_icons; fi
      - name: Prepare signing key
        run: |
          mkdir -p out
          if [ -f signing/upload-keystore.b64 ] && [ -f signing/pass.txt ]; then
            base64 -d signing/upload-keystore.b64 > android/app/upload-keystore.jks
            PASS=$(cat signing/pass.txt)
          else
            PASS=$(openssl rand -hex 12)
            keytool -genkeypair -keystore android/app/upload-keystore.jks -storetype JKS -keyalg RSA -keysize 2048 -validity 10000 -alias upload -storepass "$PASS" -keypass "$PASS" -dname "CN=__NAME__, OU=App, O=__NAME__, C=US"
            cp android/app/upload-keystore.jks out/upload-keystore.jks
            printf "KEYSTORE_PASSWORD=%s\nKEY_ALIAS=upload\n" "$PASS" > out/KEEP-SECRET-password.txt
          fi
          printf "storePassword=%s\nkeyPassword=%s\nkeyAlias=upload\nstoreFile=%s\n" "$PASS" "$PASS" "$GITHUB_WORKSPACE/android/app/upload-keystore.jks" > android/key.properties
      - run: python3 tools/patch_signing.py
      - run: flutter build appbundle --release --build-name=__VNAME__ --build-number=__VCODE__
      - run: flutter build apk --release --build-name=__VNAME__ --build-number=__VCODE__
      - uses: actions/upload-artifact@v4
        with:
          name: release-files
          path: |
            build/app/outputs/bundle/release/app-release.aab
            build/app/outputs/flutter-apk/app-release.apk
      - uses: actions/upload-artifact@v4
        with:
          name: KEEP-SECRET-keystore
          path: out/
          if-no-files-found: ignore
''';

const _patchPy = r'''
import sys

p = "android/app/build.gradle.kts"
s = open(p, encoding="utf-8").read()

load = """val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {"""

signing = """signingConfigs {
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String
            keyPassword = keystoreProperties["keyPassword"] as String
            storeFile = file(keystoreProperties["storeFile"] as String)
            storePassword = keystoreProperties["storePassword"] as String
        }
    }

    buildTypes {"""

if "android {" not in s or "buildTypes {" not in s:
    sys.exit("build.gradle.kts format not recognized")

s = s.replace("android {", load, 1)
s = s.replace("buildTypes {", signing, 1)
s = s.replace('signingConfigs.getByName("debug")', 'signingConfigs.getByName("release")')
s = "import java.util.Properties\nimport java.io.FileInputStream\n\n" + s
open(p, "w", encoding="utf-8").write(s)
print("signing patched")
''';
